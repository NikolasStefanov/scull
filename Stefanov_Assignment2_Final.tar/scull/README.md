"I pledge my honor that I have abided by the Stevens Honor System."

Name: Nikolas Stefanov

Repo: https://github.com/NikolasStefanov/scull.git
